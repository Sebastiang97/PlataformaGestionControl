<?php
    define('url','http://localhost/platform/');

    define('host','localhost');
    define('user','root');
    define('password','123456789');
    define('dataBase','database_platform');
    define('charset','utf8mb4');

?>

