const app = new Vue({
	el: '#app',
	data: {
		addNewUser: false	
	},
	
	created: function(){
		console.log("inicializacion ")
	}
})