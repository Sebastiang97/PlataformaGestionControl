<?php require_once 'Conect.php'; 
?>
 
<!DOCTYPE html> 
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width" initial-scale="1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title></title>
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>


<body>
	
	<div id="app" class="container ml-0">

		<div class="row">
			<h1 class="col-lg-10 col-md-10 col-sm-12 float-lg-left float-md-left float-sm-left">Matriz estrategica</h1>
		</div>
		<hr>
		<table class="table table-hover" >
			
			<thead class="thead-dark ">
			<tr>
				<th scope="col">LBMetaResultado</th>
				<th scope="col">MetaResultado</th>
				
				<th scope="col">IndMetaProducto</th>
				<th scope="col">MetaCuaternio</th>

				<th scope="col">LBMetaProducto</th>
				<th scope="col">MetaProducto</th>

				<th scope="col">IndMetaProducto</th>
				<th scope="col">TipoMeta</th>

				<th scope="col">MetaCuaternioProducto</th>

				<th scope="col">Primer A Plan</th>  
				<th scope="col">Primer A Ejecucion</th> 

				<th scope="col">Segundo A Plan</th>  
				<th scope="col">Segundo A Ejecucion</th> 

				<th scope="col">Tercer A Plan</th>  
				<th scope="col">tercer A Ejecucion</th>

				<th scope="col">Cuarto A Plan</th>  
				<th scope="col">Cuarto A Ejecucion</th>  
    		</tr>
  			</thead>
  			<tbody>
			    <tr>
			      <?php 
				$sql = "SELECT * FROM matriz_estrategica WHERE id>1";
				$result = $conn->query($sql);
			
				if($result->num_rows > 0) {
					
					while($row = $result->fetch_assoc()) {
						echo "<tr>
							<td>".$row['LBMetaResultado']."</td>
							<td>".$row['MetaResultado']."</td>

							<td>".$row['IndMetaResultado']."</td>
							<td>".$row['MetaCuaternio']."</td>

							<td>".$row['LBMetaProducto']."</td>
							<td>".$row['MetaProducto']."</td>

							<td>".$row['IndMetaProducto']."</td>
							<td>".$row['TipoMeta']."</td>

							<td>".$row['MetaCuaternioProducto']."</td>
							<td>".$row['PrimerAPlan']."</td>

							<td><button class='btn btn-primary btn-sm' @click='addNewUser = true'>modify</button></td>
							<td>".$row['SegundoAPlan']."</td>

							<td>".$row['SegundoAEjecucion']."</td>
							<td>".$row['TercerAPlan']."</td>

							<td>".$row['TercerAEjecucion']."</td>
							
							<td>".$row['CuartoAPlan']."</td>
							<td>".$row['CuartoAEjecucion']."</td>

							</tr>";
					}
				} else {
					echo "<tr><td colspan='5'><center>No Data Avaliable</center></td></tr>";
				}
				?>
			    </tr>
			</tbody>
		</table>
		<div id="cont" class="container fixed-top mt-5" v-if="addNewUser">
			<div class="bg-light rounded mt-5">
				<div class="row btn-primary rounded-top">
					<h1 class="col-sm-11 float-lg-left float-md-left float-sm-left">Modificar primer año Plan </h1>
					<button class="col-sm-1 float-lg-right float-md-right float-sm-right btn btn-danger btn-sm  " @click="addNewUser = false">x</button>
				</div>
				<form class=" mt-3">
				  <div class="form-group row">
				    <label for="staticEmail" class="col-sm-2 col-form-label my-2">Primer año planeacion</label>
				    <div class="col-sm-10">
				      <input type="text" class="form-control" id="staticEmail">
				    </div>
				  </div>
				</form>
			</div>
		</div>
		<hr>

		
	</div>

	<script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
	<script src="03.js"></script>
</body>

</html>