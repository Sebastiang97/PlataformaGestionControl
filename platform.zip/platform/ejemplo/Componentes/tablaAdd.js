Vue.component('tabla',{
	template: 
	`
	<div id="cont" class="container fixed-top mt-5" v-if="addNewUser">
			<div class="bg-light rounded mt-5">
				<div class="row btn-primary rounded-top">
					<h1 class="col-sm-11 float-lg-left float-md-left float-sm-left">Lista de usaurios</h1>
					<button class="col-sm-1 float-lg-right float-md-right float-sm-right btn btn-danger btn-sm  " @click="addNewUser = false">x</button>
				</div>
				<form class=" mt-3">
				  <div class="form-group row">
				    <label for="staticEmail" class="col-sm-2 col-form-label">Username</label>
				    <div class="col-sm-10">
				      <input type="text" class="form-control" id="staticEmail">
				    </div>
				  </div>
				  <div class="form-group row ">
				    <label for="inputPassword" class="col-sm-2 col-form-label">Email</label>
				    <div class="col-sm-10">
				      <input type="text" class="form-control" id="inputPassword" placeholder="">
				    </div>
				  </div>
				  <div class="form-group row ">
				    <label for="inputPassword" class="col-sm-2 col-form-label">Mobile</label>
				    <div class="col-sm-10">
				      <input type="text" class="form-control" id="inputPassword" placeholder="">
				    </div>
				  </div>
				</form>
			</div>
		</div>
	`,
	data(){
		return{
			
		}
	}

})
