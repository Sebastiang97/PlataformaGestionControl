<?php 
	
	class Objetivo extends Controller{
		
		function __construct()
		{
			parent::__construct();
			$this->view->objetivo = [];
		}
		function render(){
            $objetivo = new ObjetivoDesarrollo();
			$this->view->objetivo = $objetivo;
			$this->view->render('objetivo/index');
		}
		function objetivo20(){
			$objetivo = $this->model->getObjetivo20();
			$this->view->objetivo = $objetivo;
			$this->view->render('objetivo/objetivoView2');
		}
		function objetivo10(){
			$objetivo = $this->model->getObjetivo10();
			$this->view->objetivo = $objetivo;
			$this->view->render('objetivo/objetivoView1');
		}
	}

?>