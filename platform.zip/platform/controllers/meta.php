<?php 
	
	class Meta extends Controller{
		
		function __construct()
		{
			parent::__construct();
			$this->view->meta = [];
		}
		function render(){
			$meta = new Matriz();
			$this->view->meta = $meta;
			$this->view->render('meta/index');
		}
		function TasaDesercion(){
			$meta = $this->model->getTasaDesercion();
			$this->view->meta = $meta;
			$this->view->render('meta/TasaDesercion');
		}
		function TasaCobertura(){
			$meta = $this->model->getTasaCobertura();
			$this->view->meta = $meta;
			$this->view->render('meta/TasaCobertura');
		}

		function verId($param = null){
			$idmeta = $param[0];
			$meta = $this->model->getById($idmeta);
			$_SESSION['id_meta'] = $meta->id;
			$this->view->meta = $meta;
			$this->view->render("meta/edit");

		}
		
		function reporte(){
			$this->model->reporte();
			
		}

		function editar(){
			//$id = $_SESSION['id_meta'];
			$id = $_POST['id'];
			$primerAEjecucion = $_POST['primerAEjecucion'];
			$segundoAEjecucion = $_POST['segundoAEjecucion'];
			$tercerAEjecucion = $_POST['tercerAEjecucion'];
			$cuartoAEjecucion = $_POST['cuartoAEjecucion'];
			
			if ($this->model->update([
				'id'=> $id, 
				'primerAEjecucion' => $primerAEjecucion,
				'segundoAEjecucion' => $segundoAEjecucion,
				'tercerAEjecucion' => $tercerAEjecucion,
				'cuartoAEjecucion' => $cuartoAEjecucion,
				])) {
				$meta =  new Matriz();
				$meta->id = $id;
				$meta->primerAEjecucion = $primerAEjecucion;
				$meta->segundoAEjecucion = $segundoAEjecucion;
				$meta->tercerAEjecucion = $tercerAEjecucion;
				$meta->cuartoAEjecucion = $cuartoAEjecucion;
				$this->view->meta=$meta;
				$this->view->confirmacion="meta actualizada";
			}else{
				$this->view->confirmacion="Error al editar los campos";				
			}
			$this->view->render("meta/edit");
		}
		/*
		function editar($param = null){
			echo "entro";
			$idMeta = $param;
			$primerAPlan = $_POST['primerAPlan'];

			if ($this->model->edit(['id'=>$idMeta, 'primerAPlan'=>$primerAPlan]))
			{
				$meta = new Matriz();
				$meta->id = $idMeta;
				$meta->primerAEjecucion= $primerAPlan;
				$this->view->meta = $meta;
				echo "easdfgas";
			}else{
				echo "no se pudo";
			}
			
			$this->view->render('meta/TasaDesercion');			
		}*/

	}



?>

