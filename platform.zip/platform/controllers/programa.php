<?php 
	
	class Programa extends Controller{
		
		function __construct()
		{
			parent::__construct();
			$this->view->programa = [];
		}
		function render(){
            $programa = new ProgramaGobierno();
			$this->view->programa = $programa;
			$this->view->render('programa/index');
		}
		function programaGobierno(){
			$programa = $this->model->getProgramaGobierno();
			$this->view->programa = $programa;
			$this->view->render('programa/programaView');
		}
	
	}

?>