<?php 
	
	class Fuentes extends Controller{
		
		function __construct()
		{
			parent::__construct();
			$this->view->fuentes = [];
		}
		function render(){
            $fuentes = new FuentesFinanciacion();
			$this->view->fuentes = $fuentes;
			$this->view->render('fuentes/index');
		}
		function sistemaParticipacion(){
			$fuentes = $this->model->getSistemaParticipacion();
			$this->view->fuentes = $fuentes;
			$this->view->render('fuentes/sistemaParticipacion');
		}
		function recursosPropios(){
			$fuentes = $this->model->getRecursosPropios();
			$this->view->fuentes = $fuentes;
			$this->view->render('fuentes/recursosPropios');
		}

		function verId($param = null){
			$idmeta = $param[0];
			$meta = $this->model->getById($idmeta);
			
			
			$_SESSION['id_meta'] = $meta->id;
			echo "id".$meta->id;
			echo "<br>session->Id:".$_SESSION['id_meta'];
			$this->view->meta = $meta;
			$this->view->mensaje="";
			$this->view->render("meta/edit");

		}

		function editar(){
			//$id = $_SESSION['id_meta'];
			$id = $_POST['id'];
			$primerAEjecucion = $_POST['primerAEjecucion'];
			$primerAPlan = $_POST['primerAPlan'];
			/*echo "<br>->Id:".$_SESSION['id_meta'];
			echo "<br>id:".$id;
			echo "<br>primerAPlan:".$primerAPlan;
			echo "<br>primerAEjecucion:".$primerAEjecucion;*/
			
			//unset($_SESSION['id_meta']);
			echo "id:".$id;
			if ($this->model->update(['id'=> $id, 'primerAEjecucion' => $primerAEjecucion])) {
				$meta =  new Matriz();
				$meta->id = $id;
				$meta->primerAEjecucion = $primerAEjecucion;
				$meta->primerAPlan = $primerAPlan;
				$this->view->meta=$meta;
				$this->view->mensaje="meta actualizada";
			}else{
				$this->view->mensaje="Error";				
			}
			$this->view->render("meta/edit");
		}

	}



?>