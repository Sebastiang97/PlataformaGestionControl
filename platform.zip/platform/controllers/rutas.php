<?php 
	
	class Rutas extends Controller{
		
		function __construct()
		{
			parent::__construct();
			$this->view->rutas = [];
		}
		function render(){
            $rutas = new RutasEspecializadas();
			$this->view->rutas = $rutas;
			$this->view->render('rutas/index');
		}
		function rutas20(){
			$rutas = $this->model->getRutas20();
			$this->view->rutas = $rutas;
			$this->view->render('rutas/rutasView2');
		}
		function rutas10(){
			$rutas = $this->model->getRutas10();
			$this->view->rutas = $rutas;
			$this->view->render('rutas/rutasView1');
		}
	}

?>