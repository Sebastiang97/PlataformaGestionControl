<?php 
	
	class Pnd extends Controller{
		
		function __construct()
		{
			parent::__construct();
			$this->view->pnd = [];
		}
		function render(){
            $pnd = new PlanNacionalDesarrollo();
			$this->view->pnd = $pnd;
			$this->view->render('pnd/index');
		}
		function pnd20(){
			$pnd = $this->model->getPnd20();
			$this->view->pnd = $pnd;
			$this->view->render('pnd/pndView2');
		}
		function pnd10(){
			$pnd = $this->model->getPnd10();
			$this->view->pnd = $pnd;
			$this->view->render('pnd/pndView1');
		}
		function pnd30(){
			$pnd = $this->model->getPnd30();
			$this->view->pnd = $pnd;
			$this->view->render('pnd/pndView3');
		}
	}

?>