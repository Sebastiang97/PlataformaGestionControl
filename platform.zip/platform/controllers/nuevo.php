<?php 

	/**
	 * 
	 */
	class Nuevo extends Controller{
		
		function __construct()
		{
			parent::__construct();
					
		}
		function render(){
			$this->view->render('nuevo/index');
		}
		function registrarMeta(){
			$meta = $_POST['meta'];
			$lBMetaResultado = $_POST['LBMetaResultado'];

			$mensaje ="";

			if ($this->model->insert(['meta'=>$meta,'LBMetaResultado'=>$lBMetaResultado])) {
				$mensaje =  "meta creada satisfactoriamente";
			}else{
				$mensaje =  "Esta meta ya esta creada ";
			}
			$this->view->mensaje = $mensaje;
			$this->render();

		}
	}
?>