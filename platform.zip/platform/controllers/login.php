<?php 

	/**
	 * 
	 */
	class Login extends Controller{
		
		function __construct()
		{
			parent::__construct();
			
			//echo "<p>Nuevo controlador main</p>";
		}
		function render(){
			$this->view->render('login/index');
		}
		function registro()
		{
			$this->view->render('login/registrar');
		}
		public function logout ()
		{
			unset($_SESSION['NombreUsuario']);
			$this->view->render('login/index');
		}
		function acceder(){
			$codigo_Dane = $_POST['Codigo_Dane'];
			$contraseña = $_POST['Contraseña'];
			$mensaje ="";
            
            $datos = [
                'Codigo_Dane'=>$codigo_Dane,
                'Contraseña'=>$contraseña,
            ];
            
			if ($this->model->verifyData($datos)) {
				//$mensaje =  "Ingreso satisfactoriamente ". $_SESSION['NombreUsuario'];
				$this->view->render('main/index');

			}else{
				$mensaje =  "Error: los datos no coinciden ";
				$this->view->mensaje = $mensaje;
				$this->render();
			}
			
		}
        function insertar()
		{
            $codigo_Dane = $_POST['Codigo_Dane'];
            $contraseña = $_POST['Contraseña'];
            $correo_Electronico = $_POST['Correo_Electronico'];
            $nombre_PND = $_POST['Nombre_PND'];
            $nombre_Municipio =$_POST['Nombre_Municipio'];
            $nombre_Alcalde = $_POST['Nombre_Alcalde'];
            $mensaje ="";
            
            $datos = [
                'Codigo_Dane'=>$codigo_Dane,
                'Contraseña'=>$contraseña,
                'Correo_Electronico'=>$correo_Electronico,
                'Nombre_PND'=>$nombre_PND,
                'Nombre_Municipio'=>$nombre_Municipio,
                'Nombre_Alcalde'=>$nombre_Alcalde
            ];
            
			if ($this->model->insertData($datos)) {
				$mensaje =  "Usuario Creado satisfactoriamente";
			}else{
				$mensaje =  "Error: en los datos ";
			}
			$this->view->mensaje = $mensaje;
			$this->render();
		}				
	}

?>