<?php 
    class Database{
        public $host;
        public $user;
        public $password;
        public $db;
        public $charset;
        

        public function __construct(){
            $this->host= constant('host');
            $this->user= constant('user');
            $this->password= constant('password');
            $this->db= constant('dataBase');
            $this->charset= constant('charset');
        }

        function connect(){
            try {
                $connection = "mysql:host=".$this->host .";dbname=".$this->db .";charset=".$this->charset;
                $options = [
                    PDO::ATTR_ERRMODE          => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ];
                $pdo = new PDO($connection, $this->user,$this->password , $options);
                return $pdo;
            }catch(PDOException $e){
                print_r('Error en la conexion: '. $e->getMessage());
            }
        }
    }

?>