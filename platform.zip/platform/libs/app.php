<?php
	require_once 'controllers/errores.php';
	class App{

		function __construct(){
			session_start();
			if (isset($_SESSION['NombreUsuario'])) {
				$this->isLogin();
			}else{
				$this->notIsLogin();
			}
		}

		public function isLogin()
		{
			$url = isset($_GET['url']) ? $_GET['url']: null;
			$url = rtrim($url, '/');
			$url = explode('/', $url);

			//la url esta vacia
			if (empty($url[0])) {
				$archivoController = 'controllers/main.php';
				require_once $archivoController;
				$controller = new Main();
				$controller->render();
				$controller->loadModel('main');
				return false;
			}else{
				$archivoController = 'controllers/' . $url[0] . '.php';
				//el archivo existe dentro de la carpeta controller
				if (file_exists($archivoController)) {
					require_once $archivoController;
					//inicializa el controller de la url
					$controller = new $url[0];
					$controller->loadModel($url[0]);

					//Elementos del arreglo
					$nparam = sizeof($url);
					if ($nparam>1) {
						if ($nparam >2) {
							$param = [];
							for ($i=2; $i < $nparam; $i++) { 
								array_push($param, $url[$i]);
							}
							$controller->{$url[1]}($param);
						}else{
							$controller->{$url[1]}();
						}
					}else{
						$controller->render();
					}
				}else{
					$controller = new Errores();
				}
			}
		}

		public function notIsLogin()
		{
			$url = isset($_GET['url']) ? $_GET['url']: null;
			$url = rtrim($url, '/');
			$url = explode('/', $url);

			//la url esta vacia
			if (empty($url[0])) {
				$archivoController = 'controllers/login.php';
				require_once $archivoController;
				$controller = new Login();
				$controller->render();
				$controller->loadModel('login');
				return false;
			}else{
				$archivoController = 'controllers/login.php';
				//el archivo existe dentro de la carpeta controller
				if (file_exists($archivoController)) {
					require_once $archivoController;
					//inicializa el controller de la url
					$controller = new Login();
					$controller->loadModel('login');

					//Elementos del arreglo
					$nparam = sizeof($url);
					if ($nparam>1) {
						if ($nparam >2) {
							$param = [];
							for ($i=2; $i < $nparam; $i++) { 
								array_push($param, $url[$i]);
							}
							
							if(isset($param)){
								echo"asdf";
							}
							
						}else{
							$controller->{$url[1]}();
						}
					}else{
						$controller->render();
					}
				}else{
					$controller = new Login();
				}
			}
		}





	}
?>

<?php 
/*
if (isset($url[1])) {
					//si la url[en la posicion 1(es decir despues de /)] se puso un metodo y este existe carguelo
					$controller->{$url[1]}();
				}else{
					//si no cargue el metodo render
					$controller->render();
				}
*/

 ?>
